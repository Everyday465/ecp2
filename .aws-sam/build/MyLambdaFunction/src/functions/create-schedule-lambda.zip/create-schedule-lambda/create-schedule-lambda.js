const AWS = require('aws-sdk');
const eventBridge = new AWS.EventBridge();

exports.handler = async (event) => {
    const ruleName = 'OneTimeScheduleRule';
    const targetArn = 'arn:aws:lambda:us-east-1:058264429730:function:ses-sender-reminder-function'; // Replace with your target Lambda ARN
    const receiverEmail = 'whoisyoutueber@gmail.com'; // The email to pass to the target Lambda

    try {
        // Calculate the time 5mins from now in UTC
        const now = new Date();
        now.setMinutes(now.getMinutes() + 5);

        // Format the time for a cron expression
        const cronExpression = `cron(${now.getUTCMinutes()} ${now.getUTCHours()} ${now.getUTCDate()} ${now.getUTCMonth() + 1} ? ${now.getUTCFullYear()})`;

        console.log('Cron Expression:', cronExpression); // Log for debugging

        // Create the one-time schedule
        await eventBridge.putRule({
            Name: ruleName,
            ScheduleExpression: cronExpression,
            State: 'ENABLED',
            Description: 'A rule that triggers once 1 hour from now',
        }).promise();

        // Add the target with a custom input payload
        await eventBridge.putTargets({
            Rule: ruleName,
            Targets: [
                {
                    Id: 'TargetLambda',
                    Arn: targetArn,
                    Input: JSON.stringify({ email: receiverEmail }),
                }
            ]
        }).promise();

        return {
            statusCode: 200,
            body: JSON.stringify({ message: 'One-time EventBridge rule created successfully' }),
        };
    } catch (error) {
        console.error('Error:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ message: 'Failed to create one-time schedule', error }),
        };
    }
};
